#include <stdio.h>

int main(int n, char * argv[]) {
    int m = 8000;
    printf("Hello world n = %d!\n", n);
    
    return m/n-1;
}
