
int calc_md5(char * data, int nLen, unsigned int md5[4])
{
    int A, B, C, D;
    // calc md5 for data array now
    // assign the result now
    md5[0] = A;
    // ...

    return 0;
}