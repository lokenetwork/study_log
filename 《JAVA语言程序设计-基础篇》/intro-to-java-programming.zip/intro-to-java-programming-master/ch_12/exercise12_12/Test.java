package ch_12.exercise12_12;

//TODO: Reset before testing
public class Test {
 
    public static void main(String[] args) {
     
     
        // Some statements
}
    static void testMethod() {
     

    }
}
