#include <stdio.h>

int main(void)
{
	puts("hello world");
	return 0;
}
