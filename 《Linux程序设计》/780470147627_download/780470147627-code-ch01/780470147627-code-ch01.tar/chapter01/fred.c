#include <stdio.h>

void fred(int arg)
{
    printf("fred: you passed %d\n", arg);
}
