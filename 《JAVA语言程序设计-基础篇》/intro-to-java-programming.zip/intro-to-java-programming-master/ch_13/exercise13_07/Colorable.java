package ch_13.exercise13_07;

/**
 * Design an interface named Colorable with a void
 * method named howToColor().
 */
public interface Colorable {

    void howToColor();
}
