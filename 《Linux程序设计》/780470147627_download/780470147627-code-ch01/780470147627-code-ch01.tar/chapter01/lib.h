/*
    This is lib.h. It declares the functions fred and bill for users
*/

void bill(char *);
void fred(int);
