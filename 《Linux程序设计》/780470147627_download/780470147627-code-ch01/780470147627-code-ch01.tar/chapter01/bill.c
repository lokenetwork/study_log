#include <stdio.h>

void bill(char *arg)
{
    printf("bill: you passed %s\n", arg);
}
