﻿// llaolao.cpp: 定义应用程序的入口点。
//

#include "llaolao.h"

using namespace std;

int main()
{
	cout << "Hello CMake." << endl;
	return 0;
}
