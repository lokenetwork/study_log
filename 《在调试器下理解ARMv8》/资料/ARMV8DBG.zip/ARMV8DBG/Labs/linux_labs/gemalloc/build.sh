gcc -g3 gemalloc.c -o gemalloc `pkg-config --cflags --libs gtk+-2.0 gthread-2.0` -lX11
