#include <stdio.h>
#include <stdlib.h>

int main(int argc, char* argv[])
{
    char* ptr = 1000;
    *ptr = '\0';
    return 0;
}
