[《Linux是怎样工作的》](https://www.ituring.com.cn/book/2867)的实验用程序


