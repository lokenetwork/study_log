package ch_01;

/**
 * 1.2 (Display five messages) Write a program that displays Welcome to Java five times
 */
public class Exercise01_02 {
    public static void main(String[] args) {
        int count = 0;

        while (count < 5) {
            System.out.print("Welcome to Java\n");
            count++;

        }
    }

}
