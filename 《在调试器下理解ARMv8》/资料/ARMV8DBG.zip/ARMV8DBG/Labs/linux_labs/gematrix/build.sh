gcc -DUSE_THR -o gematrix gematrix.c util.c thrmodel.c multiply.c -lpthread
