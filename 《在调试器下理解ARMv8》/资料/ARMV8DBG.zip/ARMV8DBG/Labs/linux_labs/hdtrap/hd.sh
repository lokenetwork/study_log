gcc -g3 -o hdtrap hdtrap.c md5.c

