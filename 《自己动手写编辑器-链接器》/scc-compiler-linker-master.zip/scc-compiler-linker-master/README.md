# scc-compiler-linker
这是<a href="https://www.zhihu.com/question/36352665" target="_blank">《自己动手写编译器、链接器》</a>一书的实践，这本书面向的是 Windows 平台，而本项目计划将其移植到 Linux，之后使用 C++ 重写这个编译器和链接器。SCC（Simplified C Compiler）是这个编译器的名字。
