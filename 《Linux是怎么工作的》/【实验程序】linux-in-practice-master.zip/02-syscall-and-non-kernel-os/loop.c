int main(void)
{
	for (;;)
		;
}
